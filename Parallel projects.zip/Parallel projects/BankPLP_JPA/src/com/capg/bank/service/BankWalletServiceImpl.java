package com.capg.bank.service;



import com.capg.bank.dao.BankWalletDao;
import com.capg.bank.dao.BankWalletDaoImpl;
import com.capg.bank.exception.InsufficientBalanceException;
import com.capg.bank.model.Account;

public class BankWalletServiceImpl implements BankWalletService {

	BankWalletDao bdao=new BankWalletDaoImpl();
	@Override
	public boolean createAccount(String accountNo, String name, String mobileNo, String aadharNo,
			String pin) {
		Account a=new Account(accountNo, name, mobileNo, aadharNo,10000, pin);
				return bdao.saveAccount(a);
	}

	@Override
	public long showBalance(String accountNo, String pin) {
		return bdao.viewBalance(accountNo, pin);
	}

	@Override
	public long deposit(String accountNo, long amount) {
		
		return bdao.depositCash(accountNo, amount);
	}

	@Override
	public long withdraw(String accountNo, String pin,long amount) throws InsufficientBalanceException {
	 
		return bdao.withdrawCash(accountNo, pin, amount);
	}

	@Override
	public boolean fundTransfer(String sourceAcNo, String destAcNo, long amount,String pin) throws InsufficientBalanceException {
		return bdao.transferMoney(sourceAcNo, destAcNo, amount,pin);
	}
	@Override
	public boolean validateAccountNumber(String accNo)
	{
		if(accNo.matches("[1-9][0-9]{11}"))
			return true;
		System.err.println("Please Enter Valid 12 Digit Account Number");
		return false;
	}
	@Override
	public boolean validatePin(String pin)
	{
		if(pin.matches("[0-9]{4}"))
			return true;
		System.err.println("Please Enter Valid 4 Digit Pin");
		return false;
	}
	@Override
    public boolean validateName(String name)
    {
    	if(name.matches("[A-Z][a-z]*"))
    		return true;
    	System.err.println("Please Enter Valid Name");
		return false;
    }
	@Override
    public boolean validateMobileNumber(String moNo)
    {
    	if(moNo.matches("[6|7|8|9][0-9]{9}"))
    		return true;
    	System.err.println("Please Enter Valid Mobile Number");
		return false;
    }
	@Override
    public boolean validateAadharNumber(String aaNo)
    {
    	if(aaNo.matches("[0-9]{12}"))
    		return true;
    	System.err.println("Please Enter Valid Aadhar Number");
    	return false;
    }
}
