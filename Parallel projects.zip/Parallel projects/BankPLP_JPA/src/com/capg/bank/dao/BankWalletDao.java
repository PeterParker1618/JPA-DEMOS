package com.capg.bank.dao;

import com.capg.bank.exception.InsufficientBalanceException;
import com.capg.bank.model.Account;

public interface BankWalletDao 
{
	  boolean saveAccount(Account a);
	  long viewBalance(String accountNo,String pin);
	  long depositCash(String accountNo,long amount);
	  long withdrawCash(String accountNo,String pin,long amount) throws InsufficientBalanceException;
	  boolean transferMoney(String sourceAcNo,String destAcNo,long amount,String pin) throws InsufficientBalanceException;
}
