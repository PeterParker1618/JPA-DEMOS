package capgemini.bankXYZ.ui;

import java.util.Scanner;

import capgemini.bankXYZ.service.BankXYZService;
import capgemini.bankXYZ.service.BankXYZServiceImpl;

public class Main {
	
	private static BankXYZService service = new BankXYZServiceImpl();
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("<****Welcome to XYZ BANK****>");
		String op = "yes";
		long accountnumber;
		while(op.equals("Yes") || op.equals("yes"))
		{
			System.out.println("Please Enter Your Choice\n1.Create Your Bank Account\n2.Show Balance\n3.Deposit\n4.Withdraw\n5.Fund Transfer\n");
			int ch = sc.nextInt();
			switch(ch)
			{
			
			case 1 : 
				service.saveCustomerInfo();
				break;
			case 2 :
				System.out.println("Enter Account Number:");
				accountnumber = sc.nextLong();
				System.out.println("The Account details are:\n"+service.showBalance(accountnumber));
				break;
			case 3 :
				System.out.println("Enter Account Number:");
				accountnumber= sc.nextLong();
				System.out.println("Enter the amount to be deposited:");
				double money1 = sc.nextDouble();
				service.depositAmount(accountnumber, money1);
				break;
			case 4 :
				System.out.println("Enter Account Number:");
				accountnumber = sc.nextLong();
				System.out.println("Enter Amount to withdraw:");
				double money = sc.nextDouble();
				service.withdrawAmount(accountnumber, money);
				break;
			case 5 :
				System.out.println("Enter Sender Account Number:");
				long senderaccountnum = sc.nextLong();
				System.out.println("Enter Reciever Account Number:");
				long recieveraccountnum = sc.nextLong();
				System.out.println("Enter ammount to be transfered:");
				long amountToTransfer = sc.nextLong();
				System.out.println(service.fundTransfer(senderaccountnum, recieveraccountnum, amountToTransfer));
				break;
			default :
				System.out.println("Please enter valid choice");
				break;
	
	 		}
			System.out.println("Do you want to continue: Yes or No");
		    op=sc.next();
		}
	}

}
