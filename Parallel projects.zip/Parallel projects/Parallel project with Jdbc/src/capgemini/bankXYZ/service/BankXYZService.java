package capgemini.bankXYZ.service;

import capgemini.bankXYZ.bean.CustomerDetails;

public interface BankXYZService {

	CustomerDetails saveCustomerInfo();
	
	String showBalance(long accnum);

	void depositAmount(long acnum, double money1);

	void withdrawAmount(long acnum1, double money);

	double fundTransfer(long yaccnum, long raccnum, long amt);

	

}
